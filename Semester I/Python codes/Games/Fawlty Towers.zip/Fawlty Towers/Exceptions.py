class RepositoryError(Exception):
    pass


class ValidationError(Exception):
    pass


class ServiceError(Exception):
    pass